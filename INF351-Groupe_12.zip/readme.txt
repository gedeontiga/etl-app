------------------------------TP2 INF3511---------------------------------

--------------------------------------------------------------------------
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>MEMBRE DU GROUPE<<<<<<<<<<<<<<<<<<<<<<<<<<<<
--------------------------------------------------------------------------
		AMBOMO TIGA GEDEON 		21T2496 (CHEF)
		MBO'O ATENA SIDONIE ORNELLA 	18T2746
		DZUNE DEFO FABRICE		23v2621
		HABU CHIMI			19M2774

CONSIGNE :
1- Executez le script python, dans l'interface qui s'affiche cliquez sur "Create database";
2- Ensuite cliquez sur "Extract data";
3- Ouvrir le fichier power BI et visualisez les graphiques sur le Dashboard.
